// This is a simple in-memory database for demonstration purposes
// In a real application, use a proper database like PostgreSQL, MongoDB, etc.

type User = {
  id: string
  name: string
  email: string
  password: string
}

type Profile = {
  id: string
  userId: string
  name: string
  title: string
  bio: string
  skills: string[]
  github?: string
  linkedin?: string
  website?: string
}

// In-memory storage
const users: User[] = []
const profiles: Profile[] = []

// Generate some sample data
function generateSampleData() {
  // Sample users
  const sampleUsers = [
    {
      id: "1",
      name: "John Doe",
      email: "john@example.com",
      password: "salt:hash", // Placeholder for hashed password
    },
    {
      id: "2",
      name: "Jane Smith",
      email: "jane@example.com",
      password: "salt:hash", // Placeholder for hashed password
    },
  ]

  // Sample profiles
  const sampleProfiles = [
    {
      id: "1",
      userId: "1",
      name: "John Doe",
      title: "Full Stack Developer",
      bio: "Experienced developer with a passion for building web applications. I specialize in React, Node.js, and TypeScript.",
      skills: ["JavaScript", "React", "Node.js", "TypeScript", "MongoDB"],
      github: "https://github.com/johndoe",
      linkedin: "https://linkedin.com/in/johndoe",
      website: "https://johndoe.dev",
    },
    {
      id: "2",
      userId: "2",
      name: "Jane Smith",
      title: "Frontend Engineer",
      bio: "Frontend developer focused on creating beautiful and accessible user interfaces. I love working with React and modern CSS.",
      skills: ["JavaScript", "React", "CSS", "HTML", "Accessibility", "UI/UX"],
      github: "https://github.com/janesmith",
      linkedin: "https://linkedin.com/in/janesmith",
    },
  ]

  users.push(...sampleUsers)
  profiles.push(...sampleProfiles)
}

// Initialize sample data
generateSampleData()

export const db = {
  // User operations
  async getUserByEmail(email: string): Promise<User | undefined> {
    return users.find((user) => user.email === email)
  },

  async getUserById(id: string): Promise<User | undefined> {
    return users.find((user) => user.id === id)
  },

  async createUser(userData: Omit<User, "id">): Promise<User> {
    const id = (users.length + 1).toString()
    const user = { id, ...userData }
    users.push(user)
    return user
  },

  // Profile operations
  async getAllProfiles(): Promise<Omit<Profile, "userId">[]> {
    return profiles.map(({ userId, ...profile }) => profile)
  },

  async getProfilesBySkill(skill: string): Promise<Omit<Profile, "userId">[]> {
    return profiles
      .filter((profile) => profile.skills.some((s) => s.toLowerCase().includes(skill.toLowerCase())))
      .map(({ userId, ...profile }) => profile)
  },

  async getProfileById(id: string): Promise<Omit<Profile, "userId"> | undefined> {
    const profile = profiles.find((p) => p.id === id)
    if (!profile) return undefined
    const { userId, ...rest } = profile
    return rest
  },

  async getProfileByUserId(userId: string): Promise<Profile | undefined> {
    return profiles.find((profile) => profile.userId === userId)
  },

  async saveProfile(profileData: Omit<Profile, "id"> & { id?: string }): Promise<Profile> {
    const existingProfile = await this.getProfileByUserId(profileData.userId)

    if (existingProfile) {
      // Update existing profile
      const updatedProfile = { ...existingProfile, ...profileData }
      const index = profiles.findIndex((p) => p.id === existingProfile.id)
      profiles[index] = updatedProfile
      return updatedProfile
    } else {
      // Create new profile
      const id = (profiles.length + 1).toString()
      const newProfile = { id, ...profileData }
      profiles.push(newProfile)
      return newProfile
    }
  },
}
