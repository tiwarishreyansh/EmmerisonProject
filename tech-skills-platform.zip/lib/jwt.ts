import * as crypto from "crypto"

// In a real application, use a proper JWT library
const JWT_SECRET = "your-secret-key" // In production, use an environment variable

export function sign(payload: object): string {
  // This is a simplified JWT implementation for demonstration purposes
  // In production, use the jsonwebtoken package
  const header = { alg: "HS256", typ: "JWT" }
  const now = Math.floor(Date.now() / 1000)
  const claims = {
    ...payload,
    iat: now,
    exp: now + 24 * 60 * 60, // 24 hours
  }

  const base64Header = Buffer.from(JSON.stringify(header)).toString("base64").replace(/=/g, "")
  const base64Payload = Buffer.from(JSON.stringify(claims)).toString("base64").replace(/=/g, "")

  const signature = crypto
    .createHmac("sha256", JWT_SECRET)
    .update(`${base64Header}.${base64Payload}`)
    .digest("base64")
    .replace(/=/g, "")

  return `${base64Header}.${base64Payload}.${signature}`
}

export function verify(token: string): object | null {
  try {
    const [headerB64, payloadB64, signature] = token.split(".")

    // Verify signature
    const expectedSignature = crypto
      .createHmac("sha256", JWT_SECRET)
      .update(`${headerB64}.${payloadB64}`)
      .digest("base64")
      .replace(/=/g, "")

    if (signature !== expectedSignature) {
      return null
    }

    // Decode payload
    const payload = JSON.parse(Buffer.from(payloadB64, "base64").toString())

    // Check if token is expired
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      return null
    }

    return payload
  } catch (error) {
    return null
  }
}
