import * as crypto from "crypto"

// In a real application, use a proper hashing library like bcrypt
export async function hash(password: string): Promise<string> {
  return new Promise((resolve) => {
    // This is a simplified hash for demonstration purposes
    // In production, use bcrypt or argon2
    const salt = crypto.randomBytes(16).toString("hex")
    const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, "sha512").toString("hex")
    resolve(`${salt}:${hash}`)
  })
}

export async function compare(password: string, hashedPassword: string): Promise<boolean> {
  return new Promise((resolve) => {
    const [salt, originalHash] = hashedPassword.split(":")
    const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, "sha512").toString("hex")
    resolve(hash === originalHash)
  })
}
