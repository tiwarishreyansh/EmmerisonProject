import type { NextRequest } from "next/server"
import { verify } from "./jwt"

export async function verifyAuth(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return null
    }

    const token = authHeader.split(" ")[1]
    const payload = verify(token)

    if (!payload) {
      return null
    }

    return payload as { id: string; email: string; name: string }
  } catch (error) {
    return null
  }
}
