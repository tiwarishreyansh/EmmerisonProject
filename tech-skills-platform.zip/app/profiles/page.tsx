"use client"

import type React from "react"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

type Profile = {
  id: string
  name: string
  title: string
  bio: string
  skills: string[]
}

export default function ProfilesPage() {
  const [profiles, setProfiles] = useState<Profile[]>([])
  const [filteredProfiles, setFilteredProfiles] = useState<Profile[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchProfiles()
  }, [])

  useEffect(() => {
    if (searchTerm.trim() === "") {
      setFilteredProfiles(profiles)
    } else {
      const term = searchTerm.toLowerCase()
      const filtered = profiles.filter(
        (profile) =>
          profile.name.toLowerCase().includes(term) ||
          profile.title.toLowerCase().includes(term) ||
          profile.bio.toLowerCase().includes(term) ||
          profile.skills.some((skill) => skill.toLowerCase().includes(term)),
      )
      setFilteredProfiles(filtered)
    }
  }, [searchTerm, profiles])

  const fetchProfiles = async () => {
    try {
      const response = await fetch("/api/profiles")
      if (response.ok) {
        const data = await response.json()
        setProfiles(data)
        setFilteredProfiles(data)
      }
    } catch (error) {
      console.error("Error fetching profiles:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // The filtering is already handled by the useEffect
  }

  const filterBySkill = (skill: string) => {
    setSearchTerm(skill)
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="text-center">Loading profiles...</div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Browse Profiles</h1>
          <p className="text-gray-500 mt-2">Discover professionals with the skills you're looking for</p>
        </div>

        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
            <Input type="search" placeholder="Search by name, title, or skill..." />
            <Input
              type="search"
              placeholder="Search by name, title, or skill..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button type="submit">Search</Button>
        </form>

        {filteredProfiles.length === 0 ? (
          <div className="text-center py-12">
            <h2 className="text-xl font-semibold">No profiles found</h2>
            <p className="text-gray-500 mt-2">Try adjusting your search criteria</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProfiles.map((profile) => (
              <Card key={profile.id}>
                <CardHeader>
                  <CardTitle>{profile.name}</CardTitle>
                  <CardDescription>{profile.title}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="line-clamp-3 text-sm text-gray-500">{profile.bio}</p>
                  <div className="flex flex-wrap gap-2 mt-4">
                    {profile.skills.slice(0, 5).map((skill) => (
                      <Badge
                        key={skill}
                        variant="secondary"
                        className="cursor-pointer"
                        onClick={() => filterBySkill(skill)}
                      >
                        {skill}
                      </Badge>
                    ))}
                    {profile.skills.length > 5 && <Badge variant="outline">+{profile.skills.length - 5} more</Badge>}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" className="w-full">
                    <Link href={`/profiles/${profile.id}`}>View Profile</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
