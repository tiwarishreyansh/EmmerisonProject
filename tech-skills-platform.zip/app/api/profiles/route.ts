import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db"
import { verifyAuth } from "@/lib/auth-middleware"

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const skill = url.searchParams.get("skill")

    let profiles
    if (skill) {
      profiles = await db.getProfilesBySkill(skill)
    } else {
      profiles = await db.getAllProfiles()
    }

    return NextResponse.json(profiles)
  } catch (error) {
    console.error("Error fetching profiles:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const profileData = await request.json()

    // Validate profile data
    if (!profileData.name || !profileData.title || !profileData.bio || !Array.isArray(profileData.skills)) {
      return NextResponse.json({ message: "Invalid profile data" }, { status: 400 })
    }

    // Create or update profile
    const profile = await db.saveProfile({
      userId: user.id,
      ...profileData,
    })

    return NextResponse.json(profile)
  } catch (error) {
    console.error("Error saving profile:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
